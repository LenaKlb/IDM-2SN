Voici notre rendu pour le mini-ptojet d'IDM.
Certains fichiers non demandés dans le mini projet sont tout de même présents:
ce sont des fichiers n'ayant pas eu de correction lors des TPs mais étant tout de même utile au projet. Sont concernés:
-simplepdl.odesign (vue graphique sirius, TP 6)
-PetriNet.Xtext (version Xtext de Petrinet, TP 5)
-Petrinet2Dot.mtl (Transformation d'un réseau de Pétri en .dot, TP 7)
-toLTL.mtl (demandé au sein du mini-projet)