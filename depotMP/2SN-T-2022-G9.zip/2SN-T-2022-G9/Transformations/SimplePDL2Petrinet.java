package petrinet.manip;


/*
méthode : 
Charger les composants du simplePDL.xmi
Décomposer les éléments en WorkDefifintion et WorkSequence
Créer les schémas de base à partir des WorkSequence
Relier ce qu'il faut avec les sources et destinations des WorkSequence
*/
import java.io.IOException;

import java.util.Collections;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import simplepdl.Guidance;
import simplepdl.ProcessElement;
import simplepdl.SimplepdlFactory;
import simplepdl.SimplepdlPackage;
import simplepdl.WorkDefinition;
import simplepdl.WorkSequence;
import simplepdl.WorkSequenceType;
import simplepdl.Process;

import petrinet.Arc;
import petrinet.Case;
import petrinet.PetriNet;
import petrinet.PetrinetFactory;
import petrinet.PetrinetPackage;
import petrinet.Place;
import petrinet.Transition;

public class SimplepdlToPetrinet{
	public static void main(String[] args) {
		
		// NE SURTOUT PAS METTRE DANS UN MEME DOSSIER !
		
		
		// PARTIE SYSTEMATIQUE
		// Partie Simple PDL modification
		
		// Chargement du package SimplePDL afin de l'enregistrer dans le registre d'Eclipse.
		SimplepdlPackage packageInstanceSimplePDL = SimplepdlPackage.eINSTANCE;
		
		// Enregistrer l'extension ".xmi" comme devant Ãªtre ouverte Ã 
		// l'aide d'un objet "XMIResourceFactoryImpl"
		Resource.Factory.Registry registreSimplePDL = Resource.Factory.Registry.INSTANCE;
		Map<String, Object> mapSimplePDL = registreSimplePDL.getExtensionToFactoryMap();
		mapSimplePDL.put("xmi", new XMIResourceFactoryImpl());
		
		// CrÃ©er un objet resourceSetImpl qui contiendra une ressource EMF (notre modÃ¨le)
				ResourceSet resSetSimplePDL = new ResourceSetImpl();

		// Charger la ressource (notre modÃ¨le)
		URI modelURI = URI.createURI("models/SimplePDLCreator_Created_Process.xmi");
		Resource resource = resSetSimplePDL.getResource(modelURI, true);
		
		// Récupérer le premier élément du modèle (élément racine)
		Process process = (Process) resource.getContents().get(0);
		
		
		
		// Création petrinet.xmi
		
		// Charger le package Petrinet afin de l'enregistrer dans le registre d'Eclipse.
		PetrinetPackage packageInstance2 = PetrinetPackage.eINSTANCE;
				
		// Enregistrer l'extension ".xmi" comme devant être ouverte à
		// l'aide d'un objet "XMIResourceFactoryImpl"
		Resource.Factory.Registry regPetri = Resource.Factory.Registry.INSTANCE;
		Map<String, Object> PetriMap = regPetri.getExtensionToFactoryMap();
		PetriMap.put("xmi", new XMIResourceFactoryImpl());
				
		// Créer un objet resourceSetImpl qui contiendra une ressource EMF (le modÃ¨le)
		ResourceSet resSetPetri = new ResourceSetImpl();

		// Définir la ressource (le modèle)
		URI modelURIPetri = URI.createURI("models/PetriNetConverti.xmi");
		Resource resourcePetri = resSetPetri.createResource(modelURIPetri);
				
		// La fabrique pour fabriquer les éléments de SimplePDL A ENLEVER
		PetrinetFactory myPetri = PetrinetFactory.eINSTANCE;
		PetriNet reseauPetri = myPetri.createPetriNet();
		reseauPetri.setNom("test");		
		
		// Ajouter le réseau de Petri dans le modèle 
		resourcePetri.getContents().add(reseauPetri);
		
		//PARTIE CODAGE
		
		
		// test validé du début
		System.out.println(reseauPetri.getNom());
		System.out.println("a");
		System.out.println(process.getName());
		// je suis content que ça marche, genre vraiment
		
		Integer nbPE = process.getProcessElements().size();
	    System.out.println("Nombre de ProcessElement dans " + process.getName() + " : " + nbPE);
		
	    // Schéma 
	    
	    /*Place P1 = myPetri.createPlace();
	    P1.setNom("P1");
	    P1.setNBJeton(1);
	    reseauPetri.getCase().add(P1);*/
	    
		// Décomposition en WorkSequence et WorkDefinition
		
	    // D'abord on crée les activités
	    
	    for (Object o : process.getProcessElements()) {
			if (o instanceof WorkDefinition) {
				
				WorkDefinition wd = (WorkDefinition) o;
				System.out.println("  - " + wd.getName() + " construction :");
				
				// construction Debut intermédiaire auxiliaire et arrivée
				Place Pd = myPetri.createPlace();
				Place Pint = myPetri.createPlace();
				Place Paux = myPetri.createPlace();
				Place Pf = myPetri.createPlace();
				Pd.setNom("Départ " + wd.getName());
				Pd.setNBJeton(1);
				Pint.setNom("Intermédiare " + wd.getName());
				Paux.setNom("Auxiliaire " + wd.getName());
				Pf.setNom("Arrivée " + wd.getName());
				reseauPetri.getCase().add(Pd);
				reseauPetri.getCase().add(Pint);
				reseauPetri.getCase().add(Paux);
				reseauPetri.getCase().add(Pf);
				
				// Construction des transitions
				Transition debut = myPetri.createTransition();
				Transition fin = myPetri.createTransition();
				debut.setNom("Début " + wd.getName());
				fin.setNom("Fin " + wd.getName());
				reseauPetri.getCase().add(debut);
				reseauPetri.getCase().add(fin);
				
				// Construction des Arcs systématiques
				Arc add = myPetri.createArc();
				Arc adaux = myPetri.createArc();
				Arc adint = myPetri.createArc();
				Arc aintf = myPetri.createArc();
				Arc aff = myPetri.createArc();
				add.setCondition(1);
				adaux.setCondition(1);
				adint.setCondition(1);
				aintf.setCondition(1);
				aff.setCondition(1);
				add.setSource(Pd);
				add.setCible(debut);
				adaux.setSource(debut);
				adaux.setCible(Paux);
				adint.setSource(debut);
				adint.setCible(Pint);
				aintf.setSource(Pint);
				aintf.setCible(fin);
				aff.setSource(fin);
				aff.setCible(Pf);
				reseauPetri.getArc().add(add);
				reseauPetri.getArc().add(adaux);
				reseauPetri.getArc().add(adint);
				reseauPetri.getArc().add(aintf);
				reseauPetri.getArc().add(aff);
				
				System.out.print("construction " + wd.getName() );
				System.out.println(" réussie");
			}
		}
		
	    for (Object o : process.getProcessElements()) {
			if (o instanceof WorkSequence) {
				WorkSequence ws = (WorkSequence) o;
				switch(ws.getLinkType().getValue()) {
				//StartToStart
				case 0 :
					Arc auxDebutautre = myPetri.createArc();
					Arc reciproque = myPetri.createArc();
					auxDebutautre.setCondition(1);
					reciproque.setCondition(1);
					Case candidatSource = (Case) reseauPetri.getCase().get(0);
					Case candidatCible = (Case) reseauPetri.getCase().get(0);
					for (Case c :  reseauPetri.getCase()) {
						if(c.getNom().contentEquals("Auxiliaire " + ws.getPredecessor().getName())){
							candidatSource = c;
							
						}
						else if(c.getNom().contentEquals("Début " + ws.getSuccessor().getName())){
							candidatCible = c;
							
						}
					}
					auxDebutautre.setSource(candidatSource);
					auxDebutautre.setCible(candidatCible); 
					reciproque.setSource(candidatCible);
					reciproque.setCible(candidatSource); 
					reseauPetri.getArc().add(auxDebutautre);
					reseauPetri.getArc().add(reciproque);
					break;
					
				// FinishToStart
				case 1 :
					Arc finAutreDebut = myPetri.createArc();
					Arc reciproque2 = myPetri.createArc();
					finAutreDebut.setCondition(1);
					reciproque2.setCondition(1);
					Case candidatSource2 = (Case) reseauPetri.getCase().get(0);
					Case candidatCible2 = (Case) reseauPetri.getCase().get(0);
					for (Case c :  reseauPetri.getCase()) {
						if(c.getNom().contentEquals("Arrivée " + ws.getPredecessor().getName())){
							candidatSource2 = c;
						}
						else if(c.getNom().contentEquals("Début " + ws.getSuccessor().getName())){
							candidatCible2 = c;
						}
					}
					finAutreDebut.setSource(candidatSource2);
					finAutreDebut.setCible(candidatCible2); 
					reciproque2.setSource(candidatCible2);
					reciproque2.setCible(candidatSource2); 
					reseauPetri.getArc().add(finAutreDebut);
					reseauPetri.getArc().add(reciproque2);
					break;
				
				// StartToFinish
				case 2 :
					Arc auxAutreFin = myPetri.createArc();
					Arc reciproque3 = myPetri.createArc();
					auxAutreFin.setCondition(1);
					reciproque3.setCondition(1);
					Case candidatSource3 = (Case) reseauPetri.getCase().get(0);
					Case candidatCible3 = (Case) reseauPetri.getCase().get(0);
					for (Case c :  reseauPetri.getCase()) {
						if(c.getNom().contentEquals("Auxiliaire " + ws.getPredecessor().getName())){
							candidatSource3 = c;
						}
						else if(c.getNom().contentEquals("Fin " + ws.getSuccessor().getName())){
							candidatCible3 = c;
						}
					}
					auxAutreFin.setSource(candidatSource3);
					auxAutreFin.setCible(candidatCible3); 
					reciproque3.setSource(candidatCible3);
					reciproque3.setCible(candidatSource3); 
					reseauPetri.getArc().add(auxAutreFin);
					reseauPetri.getArc().add(reciproque3);
					break;
					
				// FinishToFinish
				case 3 :
					Arc finAutre = myPetri.createArc();
					Arc reciproque4 = myPetri.createArc();
					finAutre.setCondition(1);
					reciproque4.setCondition(1);
					Case candidatSource4 = (Case) reseauPetri.getCase().get(0);
					Case candidatCible4 = (Case) reseauPetri.getCase().get(0);
					for (Case c :  reseauPetri.getCase()) {
						if(c.getNom().contentEquals("Arrivée " + ws.getPredecessor().getName())){
							candidatSource4 = c;
						}
						else if(c.getNom().contentEquals("Fin " + ws.getSuccessor().getName())){
							candidatCible4 = c;
						}
					}
					finAutre.setSource(candidatSource4);
					finAutre.setCible(candidatCible4); 
					reciproque4.setSource(candidatCible4);
					reciproque4.setCible(candidatSource4); 
					reseauPetri.getArc().add(finAutre);
					reseauPetri.getArc().add(reciproque4);
					break;
					default:
						System.out.println("oui c'est pas robuste");
					
				}
			}
		}
		
		
		
		// Sauver la ressource, sans ça le travail tombe à l'eau
	    try {
	    	resourcePetri.save(Collections.EMPTY_MAP);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}